package com.example.flutter_dialogflow

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
